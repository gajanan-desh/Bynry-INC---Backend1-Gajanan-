# consumer_services/models.py

from django.db import models
from django.contrib.auth.models import User
import uuid

class ServiceRequest(models.Model):
    TRACK_STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('IN_PROGRESS', 'In Progress'),
        ('COMPLETED', 'Completed'),
    ]

    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    request_type = models.CharField(max_length=100)
    details = models.TextField()
    attachment = models.FileField(upload_to='attachments/')
    submitted_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50, default='Pending')
    track_id = models.UUIDField(default=uuid.uuid4, editable=False)

    def __str__(self):
        return f"ServiceRequest - {self.id} by {self.customer.username}"

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=20)
    # Add more fields as needed

    def __str__(self):
        return f"Customer - {self.user.username}"
