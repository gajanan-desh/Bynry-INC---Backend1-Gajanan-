from django.contrib import admin
from django.urls import path, include
from consumer_services import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('consumer_services.urls')),  # Include consumer_services URL patterns
]
